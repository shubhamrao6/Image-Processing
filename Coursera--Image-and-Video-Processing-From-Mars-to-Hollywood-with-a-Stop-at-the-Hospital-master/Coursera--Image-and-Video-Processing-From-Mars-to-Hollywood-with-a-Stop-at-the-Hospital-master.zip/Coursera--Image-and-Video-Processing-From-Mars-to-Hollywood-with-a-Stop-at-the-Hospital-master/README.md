# Coursera--Image-and-Video-Processing-From-Mars-to-Hollywood-with-a-Stop-at-the-Hospital
Image Processing My code from the programming tasks of the online course "Image and video processing: From Mars to Hollywood with a stop at the hospital" from Duke University at Coursera.  
Uses Python and OpenCV
